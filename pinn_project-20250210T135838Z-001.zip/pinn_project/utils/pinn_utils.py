import numpy as np
import matplotlib.pyplot as plt
from pyDOE import lhs
import tensorflow as tf
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass

@dataclass 
class LossHistory:
    """Track training losses over time"""
    total_loss: List[float]
    physics_loss: List[float]
    boundary_loss: List[float]
    iterations: List[int]
    
    def plot_losses(self, log_scale: bool = True):
        """Plot training history"""
        plt.figure(figsize=(10, 6))
        plt.plot(self.iterations, self.total_loss, 'b-', label='Total Loss')
        plt.plot(self.iterations, self.physics_loss, 'r--', label='Physics Loss')
        plt.plot(self.iterations, self.boundary_loss, 'g:', label='Boundary Loss')
        if log_scale:
            plt.yscale('log')
        plt.xlabel('Iteration')
        plt.ylabel('Loss')
        plt.legend()
        plt.grid(True)
        return plt.gcf()

def generate_collocation_points(
    n_points: int,
    bounds: List[Tuple[float, float]],
    method: str = 'lhs'
) -> np.ndarray:
    """Generate collocation points using Latin Hypercube Sampling
    
    Args:
        n_points: Number of points to generate
        bounds: List of (min, max) tuples for each dimension
        method: Sampling method ('lhs' or 'uniform')
        
    Returns:
        Array of shape (n_points, n_dims) with sampled points
    """
    n_dims = len(bounds)
    
    if method == 'lhs':
        # Generate LHS samples between [0,1]
        samples = lhs(n_dims, samples=n_points)
    else:
        samples = np.random.uniform(0, 1, (n_points, n_dims))
        
    # Scale to actual bounds
    for i, (lower, upper) in enumerate(bounds):
        samples[:, i] = samples[:, i] * (upper - lower) + lower
        
    return samples

def plot_solution_1d(
    t: np.ndarray,
    y_pred: np.ndarray,
    y_true: Optional[np.ndarray] = None,
    labels: Optional[List[str]] = None
):
    """Plot 1D solution comparison
    
    Args:
        t: Time points
        y_pred: Predicted solution (n_points, n_vars)
        y_true: True solution if available
        labels: Variable labels
    """
    n_vars = y_pred.shape[1] if len(y_pred.shape) > 1 else 1
    
    if labels is None:
        labels = [f'var_{i}' for i in range(n_vars)]
        
    plt.figure(figsize=(12, 4*n_vars))
    for i in range(n_vars):
        plt.subplot(n_vars, 1, i+1)
        plt.plot(t, y_pred[:,i] if n_vars > 1 else y_pred, 'b-', label='Predicted')
        if y_true is not None:
            plt.plot(t, y_true[:,i] if n_vars > 1 else y_true, 'r--', label='True')
        plt.xlabel('t')
        plt.ylabel(labels[i])
        plt.legend()
        plt.grid(True)
    return plt.gcf()

def plot_phase_space(
    solution: np.ndarray,
    vars: Tuple[int, int, int] = (0, 1, 2)
):
    """Plot 3D phase space trajectory
    
    Args:
        solution: Solution array of shape (n_points, n_vars)
        vars: Tuple of indices for x,y,z variables
    """
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    ax.plot3D(solution[:,vars[0]], 
            solution[:,vars[1]], 
            solution[:,vars[2]], 'b-')
    
    ax.set_xlabel(f'x_{vars[0]}')
    ax.set_ylabel(f'x_{vars[1]}')
    ax.set_zlabel(f'x_{vars[2]}')
    
    return fig

def compute_gradient(
    model: tf.keras.Model,
    x: tf.Tensor,
    order: int = 1
) -> tf.Tensor:
    """Compute gradient of model output w.r.t input
    
    Args:
        model: Neural network model
        x: Input tensor
        order: Order of derivative (1 or 2)
        
    Returns:
        Gradient tensor
    """
    with tf.GradientTape() as tape1:
        tape1.watch(x)
        with tf.GradientTape() as tape2:
            tape2.watch(x)
            y = model(x)
        dy_dx = tape2.gradient(y, x)
        
    if order == 2:
        return tape1.gradient(dy_dx, x)
    return dy_dx

def soft_constraint_loss(
    pred: tf.Tensor,
    true: tf.Tensor
) -> tf.Tensor:
    """Compute MSE loss for soft constraints"""
    return tf.reduce_mean(tf.square(pred - true))

def physics_loss(
    residual: tf.Tensor
) -> tf.Tensor:
    """Compute MSE loss for physics residual"""
    return tf.reduce_mean(tf.square(residual))

