import tensorflow as tf
import numpy as np
from pyDOE import lhs

class PINN:
    def __init__(self, input_dim=1, output_dim=1, nr_units=20, nr_layers=4):
        """Initialize the PINN model.
        
        Args:
            input_dim: Dimension of input (default: 1 for time)
            output_dim: Dimension of output (default: 1)
            nr_units: Number of units per hidden layer
            nr_layers: Number of hidden layers
        """
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.nr_units = nr_units
        self.nr_layers = nr_layers
        self.model = self.build_model()
        
    def build_model(self):
        """Build the neural network model."""
        inp = b = tf.keras.layers.Input(shape=(self.input_dim,))
        
        for _ in range(self.nr_layers):
            b = tf.keras.layers.Dense(self.nr_units, activation='tanh')(b)
        
        out = tf.keras.layers.Dense(self.output_dim, activation='linear')(b)
        
        return tf.keras.models.Model(inp, out)
        
    @staticmethod
    def define_collocation_points(t_bdry, N_de=100):
        """Define collocation points using Latin Hypercube Sampling.
        
        Args:
            t_bdry: List/tuple of [t_min, t_max]
            N_de: Number of collocation points
        """
        return t_bdry[0] + (t_bdry[1] - t_bdry[0]) * lhs(1, N_de)
        
    def create_training_dataset(self, collocation_points, batch_size=None):
        """Create a TensorFlow dataset from collocation points.
        
        Args:
            collocation_points: Array of collocation points
            batch_size: Batch size for training (default: None = full batch)
        """
        N_de = len(collocation_points)
        ds = tf.data.Dataset.from_tensor_slices(collocation_points.astype(np.float32))
        ds = ds.cache()
        
        if batch_size:
            ds = ds.shuffle(N_de).batch(batch_size)
        else:
            ds = ds.batch(N_de)
            
        return ds

